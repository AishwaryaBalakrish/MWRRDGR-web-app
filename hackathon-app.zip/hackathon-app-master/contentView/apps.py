from django.apps import AppConfig


class ContentviewConfig(AppConfig):
    name = 'contentView'
