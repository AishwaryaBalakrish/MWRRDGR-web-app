from django.contrib import admin
from .models import CoursesList
# Register your models here.
admin.site.register(CoursesList)