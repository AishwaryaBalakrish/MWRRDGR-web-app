from django.contrib import admin
from input.models import WaterDataTemp
# Register your models here.

admin.site.register(WaterDataTemp)
