from django.apps import AppConfig


class InputConfig(AppConfig):
    name = 'input'
