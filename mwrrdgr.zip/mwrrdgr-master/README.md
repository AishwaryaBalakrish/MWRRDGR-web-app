# mwrrdgr
A web app created during the Smart India Hackathon 2018
This web app lets people upload data about water resources and then allows them to view it in tabular format as well as graphs and also  allows generation of pdfs as well as mailing of pdfs.
