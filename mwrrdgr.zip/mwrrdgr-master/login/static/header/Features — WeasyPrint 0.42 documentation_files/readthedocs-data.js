  var READTHEDOCS_DATA = {
    project: "weasyprint",
    version: "latest",
    language: "en",
    programming_language: "py",
    subprojects: {},
    canonical_url: "http://weasyprint.readthedocs.io/en/stable/",
    theme: "sphinx_rtd_theme",
    builder: "sphinx",
    docroot: "/docs/",
    source_suffix: ".rst",
    api_host: "https://readthedocs.org",
    commit: "3b52fb05"
  };
  