// RTD Analytics Code

(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-17997319-1', 'auto', 'rtfd');
ga('rtfd.set', 'dimension1', READTHEDOCS_DATA.project);
ga('rtfd.set', 'dimension2', READTHEDOCS_DATA.version);
ga('rtfd.set', 'dimension3', READTHEDOCS_DATA.language);
ga('rtfd.set', 'dimension4', READTHEDOCS_DATA.theme);
ga('rtfd.set', 'dimension5', READTHEDOCS_DATA.programming_language);
ga('rtfd.set', 'dimension6', READTHEDOCS_DATA.builder);
ga('rtfd.send', 'pageview');



// end RTD Analytics Code
