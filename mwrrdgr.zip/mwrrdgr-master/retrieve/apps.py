from django.apps import AppConfig


class RetrieveConfig(AppConfig):
    name = 'retrieve'
