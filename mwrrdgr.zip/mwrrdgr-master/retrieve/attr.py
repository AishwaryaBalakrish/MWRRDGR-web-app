def retAttr():


	li = [ 
	["dissolved_oxygen","dissolved_oxygen"],
	["ph_val","ph_val"],
	["electrical_conductivity","electrical_conductivity"],
	["total_dissolved_solids","total_dissolved_solids"],
	["total_alkalinity","total_alkalinity"],
	["total_hardness","total_hardness"],
	["total_suspended_solids","total_suspended_solids"],
	["calcium","calcium"],
	["magnesium","magnesium"],
	["chlorides","chlorides"],
	["nitrate","nitrate"],
	["sulphate","sulphate"],
	["biological_oxygen_demand","biological_oxygen_demand"],
	["quality_index","quality_index"],
	]

	return li